#Gurleen Kaur Rahi - 400377038 - rahig
import sys
sys.path.append(r"c:\users\rahig\appdata\local\packages\pythonsoftwarefoundation.python.3.9_qbz5n2kfra8p0\localcache\local-packages\python39\site-packages")
import serial
import math
from mpl_toolkits.mplot3d.axes3d import Axes3D
import matplotlib.pyplot as plt


item = serial.Serial('COM3', 115200, timeout = 10)

item.reset_output_buffer()
item.reset_input_buffer()
ax = plt.axes(projection = "3d")

b = []
c = []
d = []

b_val = 0
step = 100

    
input("Press Enter to Start the Scanning")
a = s.readline()
print (a)
a = s.readline()
print (a)
a = s.readline()
print (a)
for j in range(3):
    input("Press Enter to Start the Scanning")

    for i in range(16):
        a = s.readline()
        distance = a.decode()
        print(distance, end = "")
        angle = float(i * math.pi / 8)
        d.append(int(distance) * math.cos(angle))
        c.append(int(distance) * math.sin(angle))
        b.append(b_val)
    ax.plot3D(b, c, d) 
    b_val += step;

            
item.close()

plt.show()

